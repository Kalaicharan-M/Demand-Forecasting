import xgboost as xgb
import pandas as pd
# Initialize the XGBRegressor
model = xgb.XGBRegressor()

# Load the saved model
model.load_model('final_model.json')
data = {
    'sessions': [24420],
    'online_leads_actuals': [61],
    'test_drive_request': [38],
    'offer_request': [23],
    'total_configs_finished': [2396],
    'keep_me_updated': [0],
    'dealer_locator': [2464]
}

# Create the DataFrame
df = pd.DataFrame(data)
print(model.predict(df))