import streamlit as st
import xgboost as xgb
import pandas as pd

# Load the trained model
model = xgb.XGBRegressor()
model.load_model('final_model.json')

# Streamlit application
st.title('Sales Prediction using XGBoost')

# Collecting input data
sessions = st.number_input('Sessions', min_value=0, value=24420)
online_leads_actuals = st.number_input('Online Leads Actuals', min_value=0, value=61)
test_drive_request = st.number_input('Test Drive Request', min_value=0, value=38)
offer_request = st.number_input('Offer Request', min_value=0, value=23)
total_configs_finished = st.number_input('Total Configs Finished', min_value=0, value=2396)
keep_me_updated = st.number_input('Keep Me Updated', min_value=0, value=0)
dealer_locator = st.number_input('Dealer Locator', min_value=0, value=2464)

# Button to generate prediction
if st.button('Generate Prediction'):
    # Prepare the input data
    data = {
        'sessions': [sessions],
        'online_leads_actuals': [online_leads_actuals],
        'test_drive_request': [test_drive_request],
        'offer_request': [offer_request],
        'total_configs_finished': [total_configs_finished],
        'keep_me_updated': [keep_me_updated],
        'dealer_locator': [dealer_locator]
    }
    df = pd.DataFrame(data)

    # Predict using the model
    prediction = model.predict(df)

    # Display the prediction
    st.success(f'Predicted Sales: {prediction[0]:.2f}')

